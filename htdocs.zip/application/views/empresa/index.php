<?php 
    montaTitulo('Home'); 
    montaBreadCrumb($_SERVER['REQUEST_URI']);
?>

<?php montaSlide('20%', '100%','5000' , array('1.jpg','2.jpg','3.jpg','4.jpg', '5.jpg'));  ?>
