<?php 
    montaTitulo('Regulamento'); 
?>