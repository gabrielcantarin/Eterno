<?php 
    montaTitulo('Parceiros'); 
?>