<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_Controller extends CI_Controller
{
    public function saveOrUpdateUsuario()
    {
	$this->load->model('Usuario_Model');
	$data = $this->input->post();
	
	$from = $data['from'];
	unset($data['from']);
	
	$this->Usuario_Model->saveOrUpdate($data);
	header("location:".base_url().$from);
    }
    
    public function ajaxGetUsuarioById()
    {
	$this->load->model('Usuario_Model');
	$id_usuario = $this->input->post('id_usuario');
	
	echo json_encode($this->Usuario_Model->getUsuarioById($id_usuario));
    }
    
    public function ajaxDeleteUsuarioById()
    {
	$this->load->model('Usuario_Model');
	$id_usuario = $this->input->post('id_usuario');
	
	$this->Usuario_Model->deleteUsuarioById($id_usuario);
    }
    
    public function ajaxValidaDuplicidade()
    {
	$this->load->model('Usuario_Model');
	$email_usuario = $this->input->post('email_usuario');
	$id_usuario = $this->input->post('id_usuario');
	
	echo json_encode($this->Usuario_Model->verificaDuplicidadeUsuario($email_usuario,$id_usuario));
    }
}
