<?php 
    montaTitulo('Trabalhe Conosco'); 
?>

<h2>Vagas</h2>
<p>Desculpe, mas no momento nao temos vagas em aberto.</p>